import 'package:flutter/material.dart';
//ham main
void main() {
  runApp(const MyApp());//chay ung dung flutter
}
// (Android manifest)
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: MyListView(),//goi MyCalculator
    );
  }
}
//Activity (man hinh)
class MyListView extends StatefulWidget{
  @override
  _MyListViewState createState() {
    return _MyListViewState();
  }
}
//lop quan ly trang thai cua man hinh chinh
class _MyListViewState extends State<MyListView>{
  final List<ListItem> items = [
    ListItem(title: 'Item 1', subtitle: 'Subtitle 1', imageUrl: 'https://example.com/image1.jpg'),
    ListItem(title: 'Item 2', subtitle: 'Subtitle 2', imageUrl: 'https://example.com/image2.jpg'),
    ListItem(title: 'Item 3', subtitle: 'Subtitle 3', imageUrl: 'https://example.com/image3.jpg'),
    // Thêm thông tin hình ảnh cho các ListItem khác
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('ListView Example'),
      ),
      body: ListView.builder(
        itemCount: items.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(items[index].title),
            subtitle: Text(items[index].subtitle),
            leading: CircleAvatar( // Hiển thị hình ảnh trong leading
              backgroundImage: NetworkImage(items[index].imageUrl),
            ),
            onTap: () {
              // Xử lý sự kiện khi một item được chọn
              print('Item clicked: ${items[index].title}');
            },
          );
        },
      ),
    );
  }
}
// Đối tượng đại diện cho một mục trong danh sách
class ListItem {
  final String title;
  final String subtitle;
  final String imageUrl; // Thêm thuộc tính imageUrl

  ListItem({required this.title, required this.subtitle, required this.imageUrl});
}