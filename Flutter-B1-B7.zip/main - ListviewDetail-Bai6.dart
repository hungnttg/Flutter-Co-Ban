import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
//ham main
void main() {
  runApp(const MyApp());//chay ung dung flutter
}
// (Android manifest)
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: MyListView(),//goi MyCalculator
    );
  }
}
//Activity (man hinh)
class MyListView extends StatefulWidget{
  @override
  _MyListViewState createState() {
    return _MyListViewState();
  }
}
//lop quan ly trang thai cua man hinh chinh
class _MyListViewState extends State<MyListView>{
  // final List<ListItem> items = [
  //   ListItem(title: 'Item 1', subtitle: 'Subtitle 1', imageUrl: 'https://example.com/image1.jpg'),
  //   ListItem(title: 'Item 2', subtitle: 'Subtitle 2', imageUrl: 'https://example.com/image2.jpg'),
  //   ListItem(title: 'Item 3', subtitle: 'Subtitle 3', imageUrl: 'https://example.com/image3.jpg'),
  //   // Thêm thông tin hình ảnh cho các ListItem khác
  // ];
  late List<Photo> photos;

  @override
  void initState() {
    super.initState();
    fetchDataFromServer();
  }

  Future<void> fetchDataFromServer() async {
    final response = await http.get(Uri.parse('https://jsonplaceholder.typicode.com/albums/1/photos'));

    if (response.statusCode == 200) {
      final List<dynamic> jsonData = json.decode(response.body);
      photos = jsonData.map((item) => Photo.fromJson(item)).toList();

      setState(() {});
    } else {
      throw Exception('Failed to load data from the server');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('ListView Example'),
      ),
      body: photos == null
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
        itemCount: photos.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(photos[index].title),
            leading: CircleAvatar(
              backgroundImage: NetworkImage(photos[index].thumbnailUrl),
            ),
            onTap: () {
              // Khi một item được nhấp vào, chuyển đến màn hình chi tiết
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => DetailScreen(
                    title: photos[index].title,
                    imageUrl: photos[index].url,
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
// Đối tượng đại diện cho một mục trong danh sách
class Photo {
  final String title;
  final String url;
  final String thumbnailUrl;

  Photo({required this.title, required this.url, required this.thumbnailUrl});

  factory Photo.fromJson(Map<String, dynamic> json) {
    return Photo(
      title: json['title'],
      url: json['url'],
      thumbnailUrl: json['thumbnailUrl'],
    );
  }
}
//----
//Tao file Chi tiet khi click vao item
class DetailScreen extends StatelessWidget {
  final String title;
  final String imageUrl;

  DetailScreen({required this.title, required this.imageUrl});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detail Screen'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              title,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Image.network(imageUrl),
          ],
        ),
      ),
    );
  }
}