import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(MyApp());
}

class Photo {
  final String title;
  final String url;
  final String thumbnailUrl;

  Photo({required this.title, required this.url, required this.thumbnailUrl});

  factory Photo.fromJson(Map<String, dynamic> json) {
    return Photo(
      title: json['title'],
      url: json['url'],
      thumbnailUrl: json['thumbnailUrl'],
    );
  }
}

class CartItem {
  final String title;
  final String imageUrl;

  CartItem({required this.title, required this.imageUrl});
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MyGridView(),
    );
  }
}

class MyGridView extends StatefulWidget {
  @override
  _MyGridViewState createState() => _MyGridViewState();
}

class _MyGridViewState extends State<MyGridView> {
  late List<Photo> photos;
  List<CartItem> cartItems = [];
  Photo? selectedPhoto;

  @override
  void initState() {
    super.initState();
    fetchDataFromServer();
  }

  Future<void> fetchDataFromServer() async {
    final response = await http.get(Uri.parse('https://jsonplaceholder.typicode.com/albums/1/photos'));

    if (response.statusCode == 200) {
      final List<dynamic> jsonData = json.decode(response.body);
      photos = jsonData.map((item) => Photo.fromJson(item)).toList();

      setState(() {});
    } else {
      throw Exception('Failed to load data from the server');
    }
  }

  void addToCart() {
    if (selectedPhoto != null) {
      setState(() {
        cartItems.add(CartItem(title: selectedPhoto!.title, imageUrl: selectedPhoto!.thumbnailUrl));
        selectedPhoto = null; // Đặt lại giá trị combobox sau khi thêm vào giỏ hàng
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('GridView Example'),
        actions: [
          IconButton(
            icon: Icon(Icons.shopping_cart),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ShoppingCartScreen(cartItems: cartItems),
                ),
              );
            },
          ),
        ],
      ),
      body: photos == null
          ? Center(child: CircularProgressIndicator())
          : GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 8.0,
          mainAxisSpacing: 8.0,
        ),
        itemCount: photos.length,
        itemBuilder: (context, index) {
          return Card(
            elevation: 4.0,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Expanded(
                  child: Image.network(
                    photos[index].thumbnailUrl,
                    fit: BoxFit.cover,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    photos[index].title,
                    overflow: TextOverflow.ellipsis,
                    maxLines: 2,
                    style: TextStyle(fontSize: 14.0),
                  ),
                ),
                // DropdownButton để chọn sản phẩm và thêm vào giỏ hàng
                DropdownButton<Photo>(
                  value: selectedPhoto,
                  items: photos
                      .map((photo) => DropdownMenuItem<Photo>(
                    value: photo,
                    child: Text(photo.title),
                  ))
                      .toList(),
                  onChanged: (value) {
                    setState(() {
                      selectedPhoto = value;
                    });
                  },
                ),
                // Button để thêm sản phẩm vào giỏ hàng
                ElevatedButton(
                  onPressed: addToCart,
                  child: Text('Add to Cart'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class ShoppingCartScreen extends StatelessWidget {
  final List<CartItem> cartItems;

  ShoppingCartScreen({required this.cartItems});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Shopping Cart'),
      ),
      body: ListView.builder(
        itemCount: cartItems.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(cartItems[index].title),
            leading: CircleAvatar(
              backgroundImage: NetworkImage(cartItems[index].imageUrl),
            ),
          );
        },
      ),
    );
  }
}
