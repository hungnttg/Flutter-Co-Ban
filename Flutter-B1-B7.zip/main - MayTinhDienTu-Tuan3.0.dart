import 'package:flutter/material.dart';

void main() {
  runApp(CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Calculator',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: CalculatorScreen(),
    );
  }
}

class CalculatorScreen extends StatefulWidget {
  @override
  _CalculatorScreenState createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  String displayText = '';
  double num1 = 0;
  double num2 = 0;
  String operation = '';
  bool shouldClearDisplay = false;

  void onDigitPress(String digit) {
    setState(() {
      if (shouldClearDisplay) {
        displayText = '';
        shouldClearDisplay = false;
      }
      displayText += digit;
    });
  }

  void onOperationPress(String newOperation) {
    setState(() {
      num1 = double.parse(displayText);
      operation = newOperation;
      shouldClearDisplay = true;
    });
  }

  void onEqualsPress() {
    setState(() {
      num2 = double.parse(displayText);
      switch (operation) {
        case '+':
          displayText = (num1 + num2).toString();
          break;
        case '-':
          displayText = (num1 - num2).toString();
          break;
        case '×':
          displayText = (num1 * num2).toString();
          break;
        case '÷':
          if (num2 != 0) {
            displayText = (num1 / num2).toString();
          } else {
            displayText = 'Error';
          }
          break;
        default:
          break;
      }
      shouldClearDisplay = true;
    });
  }

  void onClearPress() {
    setState(() {
      displayText = '';
      num1 = 0;
      num2 = 0;
      operation = '';
      shouldClearDisplay = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Calculator'),
      ),
      body: Column(
        children: [
          Expanded(
            child: Container(
              padding: EdgeInsets.all(16.0),
              color: Colors.black,
              alignment: Alignment.bottomRight,
              child: Text(
                displayText,
                style: TextStyle(fontSize: 36.0, color: Colors.white),
              ),
            ),
          ),
          buildButtonRow(['7', '8', '9', '÷'], onDigitPress, onOperationPress),
          buildButtonRow(['4', '5', '6', '×'], onDigitPress, onOperationPress),
          buildButtonRow(['1', '2', '3', '-'], onDigitPress, onOperationPress),
          buildButtonRow(['0', '.', '=', '+'], onDigitPress, (value) {
            if (value == '=') {
              onEqualsPress();
            } else {
              onOperationPress(value);
            }
          }),
          Container(
            color: Colors.black,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                ElevatedButton(
                  onPressed: onClearPress,
                  child: Text('C'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget buildButtonRow(List<String> buttons, Function(String) onDigitPress, Function(String) onOperationPress) {
    return Container(
      color: Colors.black,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: buttons
            .map(
              (button) => ElevatedButton(
            onPressed: () {
              if (button == '+' || button == '-' || button == '×' || button == '÷' || button == '=') {
                onOperationPress(button);
              } else {
                onDigitPress(button);
              }
            },
            child: Text(
              button,
              style: TextStyle(fontSize: 24.0),
            ),
          ),
        )
            .toList(),
      ),
    );
  }
}
