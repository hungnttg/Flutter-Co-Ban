import 'package:flutter/material.dart';
//ham main
void main() {
  runApp(const MyApp());//chay ung dung flutter
}
// (Android manifest)
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: MyListView(),//goi MyCalculator
    );
  }
}
//Activity (man hinh)
class MyListView extends StatefulWidget{
  @override
  _MyListViewState createState() {
    return _MyListViewState();
  }
}
//lop quan ly trang thai cua man hinh chinh
class _MyListViewState extends State<MyListView>{
  // Dữ liệu mảng các đối tượng
  final List<ListItem> items = [
    ListItem(title: 'Item 1', subtitle: 'Subtitle 1'),
    ListItem(title: 'Item 2', subtitle: 'Subtitle 2'),
    ListItem(title: 'Item 3', subtitle: 'Subtitle 3'),
    ListItem(title: 'Item 4', subtitle: 'Subtitle 4'),
    ListItem(title: 'Item 5', subtitle: 'Subtitle 5'),
    ListItem(title: 'Item 6', subtitle: 'Subtitle 6'),
    ListItem(title: 'Item 7', subtitle: 'Subtitle 7'),
    ListItem(title: 'Item 8', subtitle: 'Subtitle 8'),
    ListItem(title: 'Item 9', subtitle: 'Subtitle 9'),
    ListItem(title: 'Item 10', subtitle: 'Subtitle 10'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('ListView Example'),
      ),
      body: ListView.builder(
        itemCount: items.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(items[index].title),
            subtitle: Text(items[index].subtitle),
            onTap: () {
              // Xử lý sự kiện khi một item được chọn
              print('Item clicked: ${items[index].title}');
            },
          );
        },
      ),
    );
  }
}
// Đối tượng đại diện cho một mục trong danh sách
class ListItem {
  final String title;
  final String subtitle;

  ListItem({required this.title, required this.subtitle});
}