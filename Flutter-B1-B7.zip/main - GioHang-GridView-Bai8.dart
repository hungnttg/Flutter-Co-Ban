import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
//ham main
void main() {
  runApp(MyApp());
}

//android manifest
class MyApp extends StatelessWidget{
  const MyApp({super.key});//ham khoi tao
  //giao dien
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tinh tong 2 man hinh',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: MyListView1(),//goi den MyCal
    );
  }
}
//dinh nghia activity (quan ly trang thai)
class MyListView1 extends StatefulWidget{
  @override
  _MyListViewState createState() {
    return _MyListViewState();
  }
}
//dinh nghia trang thai
class _MyListViewState extends State<MyListView1>{
  late List<Photo> photos;
  List<CartItem> cartItems = []; // Danh sách sản phẩm trong giỏ hàng

  @override
  void initState() {
    super.initState();
    fetchDataFromServer();
  }

  Future<void> fetchDataFromServer() async {
    final response = await http.get(Uri.parse('https://jsonplaceholder.typicode.com/albums/1/photos'));

    if (response.statusCode == 200) {
      final List<dynamic> jsonData = json.decode(response.body);
      photos = jsonData.map((item) => Photo.fromJson(item)).toList();

      setState(() {});
    } else {
      throw Exception('Failed to load data from the server');
    }
  }

  // Hàm thêm sản phẩm vào giỏ hàng
  void addToCart(Photo photo) {
    setState(() {
      cartItems.add(CartItem(title: photo.title, imageUrl: photo.thumbnailUrl));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('GridView Example'),
        actions: [
          IconButton(
            icon: Icon(Icons.shopping_cart),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ShoppingCartScreen(cartItems: cartItems),
                ),
              );
            },
          ),
        ],
      ),
      body: photos == null
          ? Center(child: CircularProgressIndicator())
          : GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 8.0,
          mainAxisSpacing: 8.0,
        ),
        itemCount: photos.length,
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () {
              addToCart(photos[index]);
            },
            child: Card(
              elevation: 4.0,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(
                    child: Image.network(
                      photos[index].thumbnailUrl,
                      fit: BoxFit.cover,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      photos[index].title,
                      overflow: TextOverflow.ellipsis,
                      maxLines: 2,
                      style: TextStyle(fontSize: 14.0),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

//dinh nghia lop xu ly gio hang
class ShoppingCartScreen extends StatelessWidget {
  final List<CartItem> cartItems;

  ShoppingCartScreen({required this.cartItems});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Shopping Cart'),
      ),
      body: ListView.builder(
        itemCount: cartItems.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(cartItems[index].title),
            leading: CircleAvatar(
              backgroundImage: NetworkImage(cartItems[index].imageUrl),
            ),
          );
        },
      ),
    );
  }
}
//dinh nghia cac lop
//lop model photo
class Photo {
  final String title;
  final String url;
  final String thumbnailUrl;

  Photo({required this.title, required this.url, required this.thumbnailUrl});

  factory Photo.fromJson(Map<String, dynamic> json) {
    return Photo(
      title: json['title'],
      url: json['url'],
      thumbnailUrl: json['thumbnailUrl'],
    );
  }
}
//lop model gio hang
class CartItem {
  final String title;
  final String imageUrl;

  CartItem({required this.title, required this.imageUrl});
}