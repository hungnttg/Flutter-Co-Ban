import 'package:flutter/material.dart';
//ham main
void main() {
  runApp(const MyApp());//chay ung dung flutter
}
// (Android manifest)
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: MyListView(),//goi MyCalculator
    );
  }
}
//Activity (man hinh)
class MyListView extends StatefulWidget{
  @override
  _MyListViewState createState() {
    return _MyListViewState();
  }
}
//lop quan ly trang thai cua man hinh chinh
class _MyListViewState extends State<MyListView>{
  // Dữ liệu mảng
  final List<String> items = [
    'Item 1',
    'Item 2',
    'Item 3',
    'Item 4',
    'Item 5',
    'Item 6',
    'Item 7',
    'Item 8',
    'Item 9',
    'Item 10',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('ListView Example'),
      ),
      // Sử dụng ListView.builder để tối ưu hóa hiển thị dữ liệu
      body: ListView.builder(
        itemCount: items.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(items[index]),
            onTap: () {
              // Xử lý sự kiện khi một item được chọn
              print('Item clicked: ${items[index]}');
            },
          );
        },
      ),
    );
  }
}