import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: const MyStateFullWidget1(
        title: 'goi den stateFull',
      ),
    );
  }
}

class MyStateFullWidget1 extends StatefulWidget {
  final String title;
  const MyStateFullWidget1({super.key, required this.title});
  @override
  _MyState createState() => _MyState(this.title);
}

class _MyState extends State<MyStateFullWidget1> {
  int counter = 0;
  String hienthi = "";
  _MyState(String title) {
    hienthi = title;
  }
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          Text('Counter:  $counter'),
          ElevatedButton(
              onPressed: () {
                setState(() {
                  counter++;
                });
              },
              child: Text(hienthi)),
        ],
      ),
    );
  }
}
