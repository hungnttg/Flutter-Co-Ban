import 'package:flutter/material.dart';

void main() {
  runApp(MyStatelessWidget2("aaa"));
}

class MyStatelessWidget2 extends StatelessWidget {
  final String text;
  MyStatelessWidget2(this.text);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MyStatefullWidget2(),
    );
  }
}

class MyStatefullWidget2 extends StatefulWidget {
  @override
  _MyState2 createState() => _MyState2();
}

class _MyState2 extends State<MyStatefullWidget2> {
  int counter = 0;
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text('Counter : $counter'),
        SizedBox(
          height: 16.0,
        ),
        ElevatedButton(
            onPressed: () {
              setState(() {
                counter++;
              });
            },
            child: Text('Dem Tang')),
      ],
    );
  }
}
