import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

//tao model
class Product {
  String search_image;
  String styleid;
  String brands_filter_facet;
  String price;
  String product_additional_info;
  //khoi tao
  Product(
      {required this.search_image,
      required this.styleid,
      required this.brands_filter_facet,
      required this.price,
      required this.product_additional_info});
}

//Khai bao Screen (lop ket noi voi giao dien) = man hinh
class ProductListScreen extends StatefulWidget {
  @override
  _ProductListScreenState createState() => _ProductListScreenState();
}

//dinh nghia
class _ProductListScreenState extends State<ProductListScreen> {
  //khai bao list du lieu
  late List<Product> products;
  //khoi tao trang thai
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    products = [];
    fetchProducts(); //ham lay ve toan bo san pham tu server
  }

  //do doc du lieu tu server: map
  //ta dang can dang list
  //can viet 1 ham convert
  List<Product> convertMapToList(Map<String, dynamic> data) {
    List<Product> productList = [];
    data.forEach((key, value) {
      for (int i = 0; i < value.length; i++) {
        Product product = Product(
            search_image: value[i]['search_image'] ?? '',
            styleid: value[i]['styleid'] ?? 0,
            brands_filter_facet: value[i]['brands_filter_facet'] ?? '',
            price: value[i]['price'] ?? 0,
            product_additional_info: value[i]['product_additional_info'] ?? '');
        productList.add(product);
      }
    });
    return productList;
  }

  Future<void> fetchProducts() async {
    final response =
        await http.get(Uri.parse("http://192.168.201.21/aflutter/api.php"));
    //await http.get(Uri.parse("https://hungnttg.github.io/shopgiay.json"));
    if (response.statusCode == 200) {
      //neu co du lieu
      final Map<String, dynamic> data =
          json.decode(response.body); //doc du lieu va chuyen sang map
      //thiet lap trang thai moi
      setState(() {
        products = convertMapToList(data);
      });
    } else {
      throw Exception("Khong co du lieu");
    }
  }

  //layout hien thi du lieu
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("danh sach san pham"),
      ),
      body: products != null
          ? //neu co du lieu thi tra ve listview
          ListView.builder(
              itemCount: products.length,
              itemBuilder: (context, index) {
                //item
                return ListTile(
                  title:
                      Text(products[index].brands_filter_facet), //tieu de chinh
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start, //css
                    children: [
                      Text('Price: ${products[index].price}'),
                      //co the hien thi them cac truong khac o day
                    ],
                  ),
                  leading: Image.network(
                    //hien thi anh
                    products[index].search_image,
                    width: 50,
                    height: 50,
                    fit: BoxFit.cover,
                  ),
                  //them su kien
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              ProductDetailScreen(products[index])),
                    );
                  },
                );
              })
          : Center(
              child: CircularProgressIndicator(),
            ),
    );
  }
}

class ProductDetailScreen extends StatelessWidget {
  final Product product;
  ProductDetailScreen(this.product);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Product Detail'),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(padding: EdgeInsets.all(0.0)),
          //--
          Image.network(product.search_image),
          //--
          Padding(
            padding: EdgeInsets.all(0.0),
            child: Text('styleid: ${product.styleid}'),
          ),
          Padding(
            padding: EdgeInsets.all(0.0),
            child: Text('brands_filter_facet: ${product.brands_filter_facet}'),
          ),
        ],
      ),
    );
  }
}

//main
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Danh sach san pham",
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: HomeScreen(),
      //ProductListScreen(), //main goi den ProductListScreen
    );
  }
}

//dinh nghia homeScreen
class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Home Screen"),
      ),
      body: Center(
        //dinh nghia button de khi click thi goi listScreen
        child: ElevatedButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => ProductListScreen()),
            );
          },
          child: Text("Go to List Screen"),
        ),
      ),
    );
  }
}

//goi
void main() {
  runApp(const MyApp());
}
